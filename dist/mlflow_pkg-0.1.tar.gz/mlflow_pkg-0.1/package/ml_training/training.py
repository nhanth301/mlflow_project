def training_print(text):
    print('Training')