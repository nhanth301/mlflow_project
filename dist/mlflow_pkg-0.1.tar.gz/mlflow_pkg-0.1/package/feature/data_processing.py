def feature_print(text):
    print('Feature')